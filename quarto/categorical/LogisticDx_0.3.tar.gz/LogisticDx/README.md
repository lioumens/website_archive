# LogisticDx
Diagnostic tests and plots for logistic regression models.
This implements the methods and examples from:
Hosmer D, Lemeshow S (2003). *Applied logistic regression, 2nd edition*.
